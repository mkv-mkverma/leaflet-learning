india
=====

India data repository. Geographic data from [GADM.](http://gadm.org).
